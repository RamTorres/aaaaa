export interface Video {
	title: string;
	idIMDB: string;
	urlPoster: string;
	type: string;
	year: number;
	rating: number;
}
