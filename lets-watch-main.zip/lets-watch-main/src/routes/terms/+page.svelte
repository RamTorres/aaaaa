<section class="flex flex-col gap-4 text-light/70 w-full leading-7 italic">
	<h1 class="text-4xl font-bold text-white" id="dmca">DMCA</h1>
	<p>
		The owner of this site wants to indicate that there is no copyright protected content stored on
		the servers of letswatch.cz.
	</p>
	<p>
		All offered files are stored on external file hosts that are in no way associated with
		letswatch.cz.
	</p>
	<p>
		If you are a rights holder of a file listed here, do not contact us, but the providers on whose
		servers any copyrighted material is stored. letswatch.cz offers, acting like a search engine,
		only links to files and not the files themself, this is the reason why the owners of this
		website are not responsible and according to Teleservices Act also can not be held liable.
	</p>
	<p>
		The operator is not liable for copyright infringement due to the fact that no video is on its
		own server and has no way of verifying the copyright compliance of other operators who make
		these works available.
	</p>
	<p>
		We dissociate ourselves from the contents and have no influence on it. letswatch.cz is merely a
		facilitator of external content, for legally protected content the providers hosting this
		content (filehosters) are responsible.
	</p>
	<p>
		The letswatch.cz website just links to the videos, the called embedding has been declared legal
		by an EU court and therefore we're not breaking any laws.
	</p>
	<h1 class="text-4xl font-bold text-white mt-8" id="cookies">Cookies Policy</h1>
	<p class="font-semibold">What is a cookie?</p>
	<p>
		A &#8220;cookie&#8221; is a piece of information that is stored on your computer&#8217;s hard
		drive, if you agree to this, and which records how you move your way around a website so that,
		when you revisit that website, it can present tailored options based on the information stored
		about your last visit. Cookies can also be used to analyse traffic and for advertising and
		marketing purposes.
	</p>
	<p>Cookies are used by nearly all websites and do not harm your system.</p>
	<p>
		We are required to obtain your consent for all non-essential cookies used on our website. You
		can block cookies (including essential cookies) at any time by activating the setting on your
		browser that allows you to refuse the setting of all or some cookies. However, if you use your
		browser settings to block essential cookies you may not be able to access all or parts of our
		site.
	</p>
	<p class="font-semibold">How do we use cookies?</p>
	<p>
		We use cookies to track your use of our website. This enables us to understand how you use the
		site and track any patterns with regards how you are using our website. This helps us to develop
		and improve our website as well as products and / or services in response to what you might need
		or want.
	</p>
	<p class="font-semibold">Cookies are either:</p>
	<p>
		<span class="font-semibold">Session cookies:</span> these are only stored on your computer during
		your web session and are automatically deleted when you close your browser – they usually store an
		anonymous session ID allowing you to browse a website without having to log in to each page but they
		do not collect any personal data from your computer; or
	</p>
	<p>
		<span class="font-semibold">Persistent cookies:</span> a persistent cookie is stored as a file on
		your computer and it remains there when you close your web browser. The cookie can be read by the
		website that created it when you visit that website again.
	</p>
	<p class="font-semibold">Cookies can also be categorised as follows:</p>
	<p>
		<span class="font-semibold">Strictly necessary cookies:</span> These cookies are essential to enable
		you to use the website effectively, such as when buying a product and / or service. Without these
		cookies, the services available to you on our website cannot be provided. These cookies do not gather
		information about you that could be used for marketing or remembering where you have been on the
		internet.
	</p>
	<p>
		<span class="font-semibold">Performance cookies:</span> These cookies enable us to monitor and improve
		the performance of our website. For example, they allow us to count visits, identify traffic sources
		and see which parts of the site are most popular.
	</p>
	<p>
		<span class="font-semibold">Functionality cookies:</span> These cookies allow our website to remember
		choices you make and provide enhanced features. For instance, we may be able to provide you with
		news or updates relevant to the services you use. They may also be used to provide services you have
		requested such as viewing a video or commenting on a blog. The information these cookies collect
		is usually anonymised.
	</p>
	<p>
		<span class="font-semibold">Targeting cookies: </span>These cookies record your visit to our
		website, the pages you have visited and the links you have followed. We will use this
		information to make our website and the advertising displayed on it more relevant to your
		interests.
	</p>
	<p>
		<span>First and third party cookies:</span> First party cookies are cookies set by our website. Third
		party cookies are cookies on our website that are set by a website other than our website, such as
		where we have adverts on our website or use Facebook pixels so that we can show you relevant content
		from us when you are on Facebook.
	</p>
	<p class="font-semibold">Cookies we use:</p>
	<p class="font-semibold">Cookies On Our Website</p>
	<p>
		We may process data about your use of our website and services. The usage data may include your
		IP address, geographical location, browser type and version, operating system, referral source,
		length of visit, page views and website navigation paths, as well as information about the
		timing, frequency and pattern of your service use.
	</p>
	<p>
		The source of the usage data are our analytics tracking systems Google Analytics, Lead Forensics
		and Hotjar. These generate statistical and other information about our website and is used to
		create reports about the use of the website.
	</p>
	<ul>
		<li>
			Google privacy policy: <a
				href="http://www.google.com/privacypolicy.html"
				target="_blank"
				rel="  noreferrer">http://www.google.com/privacypolicy.html</a
			>
		</li>
		<li>
			HotJar: <a
				href="https://help.hotjar.com/hc/en-us/articles/115011789248-Hotjar-Cookie-Information"
				target="_blank"
				rel="  noreferrer"
				>https://help.hotjar.com/hc/en-us/articles/115011789248-Hotjar-Cookie-Information</a
			>
		</li>
	</ul>
	<p>
		To opt out of being tracked by Google Analytics across all websites, please access the following
		link: <a href="http://tools.google.com/dlpage/gaoptout" target="_blank" rel=" noreferrer"
			>http://tools.google.com/dlpage/gaoptout</a
		>.
	</p>
	<p>
		If you have any questions about the cookies that we use, feel free to email us at <a
			href="mailto:my@michalmacenka.cz">my@michalmacenka.cz</a
		>.
	</p>
</section>
