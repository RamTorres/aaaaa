<script lang="ts">
	import { page } from '$app/stores';
	//@ts-ignore
	import CopyToClipboard from 'svelte-copy-to-clipboard';

	import Button from '$lib/components/common/Button.svelte';
	import { videoInfo } from '$core/store/writable';

	let copyBtnText = 'Copy URL';
</script>

<section class="mt-16 flex gap-4 items-start flex-wrap">
	<div class="w-full max-w-[8rem] ">
		<Button look="fill" class="w-full flex justify-center " on:click
			><i class="ri-play-fill -mt-0.5" /> Play</Button
		>
	</div>
	<a href={$videoInfo.urlIMDB} target="noreferrer">
		<Button>
			<svg
				xmlns="http://www.w3.org/2000/svg"
				width="24"
				height="24"
				viewBox="0 0 24 24"
				class="
      -mt-0.5"
				><path
					d="M13.646 10.237c-.057-.032-.16-.048-.313-.048v3.542c.201 0 .324-.041.371-.122s.07-.301.07-.66v-2.092c0-.244-.008-.4-.023-.469a.223.223 0 0 0-.105-.151zm3.499 1.182c-.082 0-.137.031-.162.091-.025.061-.037.214-.037.46v1.426c0 .237.014.389.041.456.029.066.086.1.168.1.086 0 .199-.035.225-.103.027-.069.039-.234.039-.495V11.97c0-.228-.014-.377-.043-.447-.032-.069-.147-.104-.231-.104z"
				/><path
					d="M20 3H4a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zM6.631 14.663H5.229V9.266h1.402v5.397zm4.822 0H10.23l-.006-3.643-.49 3.643h-.875L8.342 11.1l-.004 3.563H7.111V9.266H8.93c.051.327.107.71.166 1.15l.201 1.371.324-2.521h1.832v5.397zm3.664-1.601c0 .484-.027.808-.072.97a.728.728 0 0 1-.238.383.996.996 0 0 1-.422.193c-.166.037-.418.055-.754.055h-1.699V9.266h1.047c.678 0 1.07.031 1.309.093.24.062.422.164.545.306.125.142.203.3.234.475.031.174.051.516.051 1.026v1.896zm3.654.362c0 .324-.023.565-.066.723a.757.757 0 0 1-.309.413.947.947 0 0 1-.572.174c-.158 0-.365-.035-.502-.104a1.144 1.144 0 0 1-.377-.312l-.088.344h-1.262V9.266h1.35v1.755a1.09 1.09 0 0 1 .375-.289c.137-.064.344-.096.504-.096.186 0 .348.029.484.087a.716.716 0 0 1 .44.549c.016.1.023.313.023.638v1.514z"
				/></svg
			>
			Database
		</Button>
	</a>
	<CopyToClipboard
		text={$page.url.href}
		on:copy={() => {
			copyBtnText = 'URL Copied';
			setTimeout(() => {
				copyBtnText = 'Copy URL';
			}, 4000);
		}}
		let:copy
	>
		<Button on:click={copy}><i class="ri-file-copy-line -mt-0.5" />{copyBtnText}</Button>
	</CopyToClipboard>
</section>
